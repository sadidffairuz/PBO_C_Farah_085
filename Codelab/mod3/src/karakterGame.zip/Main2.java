class Mobil2 {
    String nama;
    int speed;
    public Mobil2(String nama, int speed) {
        this.nama = nama;
        this.speed = speed;

    }
}
public class Main2 {
    public static void main(String[] args) {
        Mobil2 mobil1 = new Mobil2("Toyota", 340 );
    }
}
